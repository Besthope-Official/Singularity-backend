from flask import Flask, request, jsonify
from db import authors

app = Flask(__name__)

def get_author():
    pass


def create_author():
    pass


def update_author():
    pass


def delete_author():
    pass
