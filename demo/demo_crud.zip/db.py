authors = [
    {
        'id' : 1,
        'name' : 'Sliver Wolf',
        'group' : 1,
        'category' : 1
    },
    {
        'id' : 2,
        'name' : 'Kafka',
        'group' : 1,
        'category' : 1
    },
    {
        'id' : 3,
        'name' : 'March 7th',
        'group' : 2,
        'category' : 2
    },
    {
        'id' : 4,
        'name' : 'Dan Heng',
        'group' : 2,
        'category' : 3,
    },
    {
        'id' : 5,
        'name' : 'Himeko',
        'group' : 2,
        'category' : 4
    }
]